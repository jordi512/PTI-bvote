const express = require('express');
const router = express.Router();
const app = express();
var crypto = require('crypto');
var mysql = require('mysql');
var request = require('request');
const bodyParser = require("body-parser");
let ips=['172.16.4.35','172.16.4.37','172.16.4.36','172.16.4.38'];

app.use(express.json());
app.use(bodyParser.json());

var con = mysql.createConnection({
  host: "localhost",
  user: "alumne",
  password: "alumne",
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected to db!");
});

router.get('/', (req, res) => {
    res.render("index.html");
});

router.get('/login', function(req, res) {
    res.sendFile(__dirname + '/logindos.html');
});

async function sign(privateKeyJwk, message) {
    const privateKey = await crypto.subtle.importKey("jwk", privateKeyJwk, {
      name: "RSASSA-PKCS1-v1_5",
          hash: {name: "SHA-512"},
    }, false, ['sign']);
    const data = new TextEncoder().encode(message);
  
    const signature = await crypto.subtle.sign({
        name: "RSASSA-PKCS1-v1_5",
      },
      privateKey,
      data,
    );
  
    // converts the signature to a colon seperated string
    return new Uint8Array(signature).join(':');
  }


  function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min) + min); //The maximum is exclusive and the minimum is inclusive
  }
  
  router.post('/vote', (req, res, next) => {
    var query = `select pk from usuaris.usuaris where dni="11111111S" and canvote1=1`;
    var publicKey='';
    con.query(query, function (err, publicKey) {
        if (err) throw err;
        
        var privateKey=publicKey[0].pk;
        //var firma= sign(privateKey,"hola");
        var firma = "8237492374892348923748924823"
        var ip=ips[getRandomInt(0,4)];

        var jsonString = {
            "sender":publicKey[0].pk,
            "recipient":'pk_political_party',
            "signature":firma
        };
    
        var jsonObj = JSON.parse(JSON.stringify(jsonString));
        console.log(jsonObj);

        ip = '127.0.0.1';
        var url = 'http://'+ip+':5000/transactions/new';
        var headers={"content-type": "application/json"};

        request.post({
            headers: headers,
            url:     url,
            json:   true,
            body:    jsonObj

          }, function(error, response, body){
            //console.log(body);
          });
    });
    res.end();
})

function httpGet(theUrl){
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "GET", theUrl, false ); // false for synchronous request
    xmlHttp.send( null );
    return xmlHttp.responseText;
}

router.get('/chain', (req, res) => {
    var ip=ips[getRandomInt(0,4)];
    ip='127.0.0.1'
    var url = 'http://'+ip+':5000/chain';
    response=httpGet(url);
    
});

module.exports = router;
