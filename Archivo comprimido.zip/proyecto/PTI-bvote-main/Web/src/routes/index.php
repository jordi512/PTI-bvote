<?php

session_start();

    if(!isset($_SESSION['userlogin'])){
        header("Location: logindos.html");
    }

    if(isset($_GET['logout'])){
        session_destroy();
        unset($_SESSION);
        header("Location: logindos.html");
    }

?>

<p>Welcome to index</p>


<a href="index.php?logout=true">Logout</a>
