<?php
$dbhost = 'localhost';
$dbname = 'usuaris';
$dbuser = 'alumne';
$dbpass = 'alumne';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
if (mysqli_connect_error())
{
   die('No hay conexión: '.mysqli_connect_error());
}
    
$nombre = $argv[0];
$pass = $argv[1];
if(!empty($nombre) || !empty($pass)){
    $query = mysqli_query($conn,"SELECT * FROM usuaris WHERE dni = '".$nombre."' and password = '".$pass."'");
    $nr = mysqli_num_rows($query);

    if($nr == 1)
    {
        echo 'Bienvenido';
       header("Location: localhost:8080/");
    }
    else
    {
        echo 'Error al inciar sessión';
       header("Location: localhost:8080/login");
    }
}else{
    echo 'Campos vacios';
}
?>
