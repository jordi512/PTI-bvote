<?php
$dbhost = 'localhost';
$dbname = 'usuaris';
$dbuser = 'alumne';
$dbpass = 'alumne';
$conn = mysqli($dbhost, $dbuser, $dbpass, $dbname);
if (mysqli_connect_error())
{
   die('No hay conexión: '.mysqli_connect_error());
}
    
$nombre = $_POST['usuario'];
$pass = $_POST['pass'];
if(!empty($nombre) || !empty($pass)){
    $query = mysqli_query($conn,"SELECT * FROM login WHERE dni = '".$nombre."' and password = '".$pass."'");
    $nr = mysqli_num_rows($query);

    if($nr == 1)
    {
        echo 'Bienvenido';
       header("Location: index.html")
    }
    else if ($nr == 0)
    {
        echo 'Error al inciar sessión';
       header("Location: login.html");
    }
}
?>
