#!/bin/bash

#Colours
greenColour="\e[0;32m\033[1m"
endColour="\033[0m\e[0m"
redColour="\e[0;31m\033[1m"
blueColour="\e[0;34m\033[1m"
yellowColour="\e[0;33m\033[1m"
purpleColour="\e[0;35m\033[1m"
turquoiseColour="\e[0;36m\033[1m"
grayColour="\e[0;37m\033[1m"


trap ctrl_c INT

function ctrl_c(){
	echo -e "\n${yellowColour}[*]${endColour}${grayColour} Saliendo...\n${endColour}"
	tput cnorm; exit 1
}


function helpPanel(){
    echo -e "\n${yellowColour}[*]${endColour}${grayColour} Uso ./autoBase.sh\n${endColour}"
   for i in $(seq 1 85); do echo -ne "${redColour}-"; done; echo -ne "${endColour}"
   echo -e "\n\n\t${grayColour}[-a]${endColour}${yellowColour} Crear nuevas elecciones (crear base de datos)${endColour}"
   echo -e "\n\t\t${grayColour}[-R]${endColour}${yellowColour} Creacion de las elecciones con senders y recipients aleatorios ${endColour}"
   echo -e "\n\t${grayColour}[-d]${endColour}${yellowColour} Eliminar elecciones (borrar base de datos) ${endColour}"
   echo -e "\n\t${grayColour}[-s]${endColour}${yellowColour} Mostrar elecciones existentes${endColour}"
   echo -e "\n\t${grayColour}[-h]${endColour}${yellowColour} Mostrar este panel de ayuda${endColour}\n"

   exit 1
}

function showDBs(){
    databases=$(mysql -u alumne -palumne -e "show databases;" | grep -vE "information_schema|mysql|performance_schema|Database|usuaris")
    echo
    for db in $databases; do
        echo -e "\t${purpleColour}$db${endColour}"
    done
    echo
}

function deleteDB() {
    bash -c "mysql -u alumne -palumne -e \"drop database $dat\" 2>/dev/null && echo -e \"\n\t${purpleColour}Base de datos ${endColour}${grayColour}$dat${endColour}${purpleColour} borrada satisfactoriamente\n${endColour}\" || echo -e \"\n\t${redColour}Base de datos ${endColour}${grayColour}$dat${endColour}${redColour} no encontrada\n${endColour}\""
    bash -c "rm -rf ../databases/$dat 2>/dev/null"
}

function createRandomDB(){
    #1. Crear una nueva base de datos 
    #2. Importar estructura de la base de datos 
    #3. Meter informacion en la base de datos 

    #bash -c "mysql -u alumne -palumne -e \"create database $dat\"  2>/dev/null && echo -e \"\n\t${purpleColour}Base de datos ${endColour}${grayColour}$dat${endColour}${purpleColour} creada\n${endColour}\""
   
    bash -c "mysql -u alumne -palumne -e \"create database $dat\"  2>/dev/null"
    var=$?
    if [ "$var" = "0" ]; then
        echo -e "\n\t${purpleColour}Base de datos ${endColour}${grayColour}$dat${endColour}${purpleColour} creada\n${endColour}"
        bash -c "mysql -u alumne -palumne $dat < elecciones.sql"
        bash -c "mkdir ../databases/$dat"
        echo -e "\t${purpleColour}Creando 20 senders${endColour}"
        sleep 2

        for i in $(seq 1 20); do
            sender="sender$i"
            bash -c "openssl genrsa 1024 > ../databases/$dat/priv$sender"
            bash -c "openssl rsa -in ../databases/$dat/priv$sender -pubout -out ../databases/$dat/pub$sender"


            publicKey=$(bash -c "tr -d \"\n\" < ../databases/$dat/pub$sender | sed 's/KEY-----/KEY-----\\\n/' | sed 's/-----END/\\\n-----END/g'")
            bash -c "mysql -u alumne -palumne -e \"insert into $dat.sendersPK(pk) values('$publicKey')\""
            #bash -c "tr -d \"\n\" < ../databases/$dat/priv$sender | sed 's/KEY-----/KEY-----\\\n/' | sed 's/-----END/\\\n-----END/g' | sponge ../databases/$dat/priv$sender"
            #bash -c "tr -d \"\n\" < ../databases/$dat/pub$sender | sed 's/KEY-----/KEY-----\\\\n/' | sed 's/-----END/\\\\n-----END/g' | sponge ../databases/$dat/pub$sender"

        done

        echo -e "\t${purpleColour}Senders creados${endColour}"

        echo -e "\t${purpleColour}Creando 5 recipients${endColour}"
        sleep 2
        for i in $(seq 1 5); do
            recipient="recipients$i"
            bash -c "openssl genrsa 1024 > ../databases/$dat/priv$recipient"
            bash -c "openssl rsa -in ../databases/$dat/priv$recipient -pubout -out ../databases/$dat/pub$recipient"

            publicKey=$(bash -c "tr -d \"\n\" < ../databases/$dat/pub$recipient | sed 's/KEY-----/KEY-----\\\n/' | sed 's/-----END/\\\n-----END/g'")
            bash -c "mysql -u alumne -palumne -e \"insert into $dat.recipientsPK(pk,entidad) values('$publicKey','$i')\""

            #bash -c "tr -d \"\n\" < ../databases/$dat/priv$recipient | sed 's/KEY-----/KEY-----\\\n/' | sed 's/-----END/\\\n-----END/g' | sponge ../databases/$dat/priv$recipient"
            #bash -c "tr -d \"\n\" < ../databases/$dat/pub$recipient | sed 's/KEY-----/KEY-----\\\n/' | sed 's/-----END/\\\n-----END/g' | sponge ../databases/$dat/pub$recipient"
        done
        echo -e "\t${purpleColour}Recipients creados${endColour}"
        sleep 1
        echo -e "\n\t${greenColour}Elecciones creadas\n${endColour}"

    else 
        echo -e "\n\t${redColour}Base de datos ${endColour}${grayColour}$dat${endColour}${redColour} ya existe\n${endColour}"
    fi
}

function createDB(){
    bash -c "mysql -u alumne -palumne -e \"create database $dat\"  2>/dev/null"
    var=$?
    if [ "$var" = "0" ]; then
        
        echo -e "\n\t${purpleColour}Base de datos ${endColour}${grayColour}$dat${endColour}${purpleColour} creada\n${endColour}"

        bash -c "mysql -u alumne -palumne $dat < elecciones.sql"
        bash -c "mkdir ../databases/$dat"
        echo -e "\t${purpleColour}Escribe las public keys de los senders. Cuando acabes escribe 'FIN' ${endColour}"
        sleep 1
        echo -n "$>"
        read publicKey
        iterator=1
        while [[ "$publicKey" != "FIN"  ]]; do    
            sender="sender$iterator"
            bash -c "mysql -u alumne -palumne -e \"insert into $dat.sendersPK(pk) values('$publicKey')\""
            echo -e "\n\t${greenColour}Sender añadido correctamente\n${endColour}"
            bash -c "echo \"$publicKey\" > ../databases/$dat/pub$sender"
            echo -n "$>"
            read publicKey
            iterator=$iterator+1
        done
        echo -e "\t${purpleColour}Se han creado $iterator senders ${endColour}"
        sleep 1
        echo -e "\t${purpleColour}Escribe las entidades de los partidos y sus public keys. Cuando acabes escribe 'FIN' ${endColour}"
        sleep 1

        echo -n "$>"
        read entidad
        iterator=1
        while [[ "$entidad" != "FIN" ]];do
            echo -n "$>"
            read publicKey
            recipient="recipients"$iterator
            bash -c "mysql -u alumne -palumne -e \"insert into $dat.recipientsPK(pk,entidad) values('$publicKey','$entidad')\""
            bash -c "echo \"$publicKey\" > ../databases/$dat/pub$recipient"
            echo -e "\n\t${greenColour}Recipient añadido correctamente\n${endColour}"
            echo -n "$>"
            read entidad
            iterator=$iterator+1
        done
        echo -e "\n\t${greenColour}Elecciones creadas\n${endColour}"
    else
        echo -e "\n\t${redColour}Base de datos ${endColour}${grayColour}$dat${endColour}${redColour} ya existe\n${endColour}"
    fi
}

parameter_counter=0;while getopts "a:d:Rsh" arg; do
    case $arg in
        a) dat=$OPTARG; let parameter_counter=1;;
        d) dat=$OPTARG; let parameter_counter=2; deleteDB;;
        R) let parameter_counter=3;;
        s) showDBs; let parameter_counter=4;;
        h) helpPanel;;
    esac
done

if [ $parameter_counter -eq 0 ]; then
    helpPanel
elif [ $parameter_counter -eq 1 ]; then
    createDB
elif [ $parameter_counter -eq 3 ]; then
    createRandomDB
fi


